# Unit Commitment Pipeline — Reproducible Research Template

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USERNAME/REPONAME/blob/main/notebooks/00_pipeline_walkthrough.ipynb)

A worked template for optimization/simulation research code: CSV in →
clean → MILP → CSV out → figures. The model here is a toy unit-commitment
problem, but the **structure** is the point — swap the model, keep the skeleton.

## Reproduce everything

```bash
pip install -r requirements.txt
python scripts/run_all.py
pytest -q
```

One command. If a clean clone doesn't reproduce the figures, the repo is broken.

Run a different scenario without touching any code:

```bash
python scripts/run_all.py --config scenarios/high_reserve.yaml
```

## Layout

```
config.yaml              every parameter — the ONLY place numbers live
requirements.txt         pinned deps, with upper bounds
scenarios/               alternate configs (a scenario is a file, not a fork)

data/raw/                READ-ONLY inputs. Never written to. Committed.
data/interim/            validated/cleaned. Gitignored — regenerate it.
data/processed/          model outputs. Gitignored — regenerate it.

src/dispatch/
  config.py              resolves paths + loads config.yaml
  clean.py               raw -> interim   (validation lives here)
  model.py               interim -> processed  (the MILP)
  analyze.py             processed -> figures/tables

scripts/run_all.py       orchestrates the three stages
notebooks/
  00_pipeline_walkthrough.ipynb   thin: imports src, proves reproducibility
  01_model_explained.ipynb        teaching: builds from scratch, then
                                  ASSERTS it matches src (CI enforces)
results/figures/         committed on purpose (see below)
results/tables/          gitignored — regenerate it
tests/test_smoke.py      does it run, and is the physics sane
.github/workflows/ci.yml runs the pipeline on every push
```

## Why it's built this way

**Two notebooks, two jobs.** The real risk with notebooks is not
duplication itself — it's *undetected* duplication. So:

- `00_pipeline_walkthrough.ipynb` imports and calls `clean.run()`,
  `model.run()`, `analyze.run()` — the exact functions `run_all.py` calls.
  It cannot drift because it holds no logic.
- `01_model_explained.ipynb` is a teaching notebook and *is* allowed to
  build a simplified model from scratch, because good pedagogy needs
  visible construction. Its final cell rebuilds the production model on
  the same instance and **asserts the two costs match**. `pytest` executes
  every notebook, so if `model.py` changes and the explanation stops being
  true, CI goes red.

Techniques that teach without duplicating at all:
`inspect.getsource(model.build_problem)` renders the *live* source in the
notebook; printing `prob.constraints` shows the generated formulation;
`ipywidgets.interact` turns parameters into sliders.

**Raw data is immutable.** `data/raw/` is never written to by any stage.
If a cleaning step is wrong, you fix the code and re-run; you never lose
the original.

**Three data tiers, not one output folder.** Mixing cleaned inputs with
final results in one directory makes it impossible to tell what's
derived from what. raw → interim → processed is a one-way flow.

**Generated files are gitignored, with one deliberate exception.**
Intermediates and tables regenerate in seconds, so versioning them just
makes diffs unreadable and the repo fat. `results/figures/` **is** tracked,
because a reader landing on the repo should see the outputs without
running anything, and because a figure tied to a specific commit is
evidence of what the code produced at submission time.

**Parameters live in config, not in code.** A reserve margin buried on
line 140 of `model.py` is invisible. In `config.yaml` it's a documented knob,
and a scenario becomes a new YAML file instead of a copy-pasted script.

**Deps are pinned with upper bounds.** An unpinned `pulp` will one day
install a major version with a changed API and silently break — or worse,
subtly change — results you already published.

**A smoke test exists.** Not unit tests for research correctness — a test
that the pipeline runs end-to-end, demand is met, and no unit exceeds
capacity. This is the highest-value-per-line test for research code, and
it's what makes the CI badge meaningful.

## Data policy

Small sample inputs are committed so the Colab badge works for anyone.
For real work, pick one:

- **Small + shareable (< ~50 MB):** commit it, as done here.
- **Large or restricted:** keep it out of git; add a `scripts/fetch_data.py`
  that pulls from Zenodo / an institutional store, and commit a tiny
  synthetic sample so tests and the Colab demo still run.

Never commit real data you can't publish — git history is forever, and
removing a file in a later commit does **not** remove it from history.

## Reproducing a specific paper

Tag the commit that produced the results:

```bash
git tag -a paper-2026-ieee -m "Results for Table 2 and Figure 4"
git push origin paper-2026-ieee
```

Then cite that tag. You keep developing on `main` without invalidating
what a reviewer can check.

## Colab

The badges open the notebooks in a free cloud VM — no install, no download.
Edit the badge URL and `REPO_URL` in cell 0 to point at your repo.

For the badge to work **for a stranger**, all of these must hold:

1. **The repo is public.** Colab's `git clone` has no credentials; a
   private repo fails with an auth error.
2. **The package installs itself.** Cell 0 runs `pip install -e .`, which
   is why `pyproject.toml` exists. `sys.path` hacks break the moment
   someone's working directory differs.
3. **Inputs are committed** (or fetched by a script). Colab cannot see
   your hard drive.
4. **The solver is pip-installable.** CBC ships bundled with PuLP and
   HiGHS installs via `highspy`. Gurobi/CPLEX need a license — the pip
   `gurobipy` ships only a size-limited trial, so gate licensed solvers
   behind a config option and default to CBC/HiGHS for the public path.
5. **No dependency conflicts with Colab's preinstalled stack.** Colab pins
   its own numpy/pandas; an install that upgrades them may demand a
   runtime restart. Wide-but-bounded pins avoid forcing that.

CI is what actually verifies 1–5: it runs on a clean Ubuntu box with no
prior state, which is a close analogue of a stranger's Colab. If CI is
green, the badge almost certainly works.

(In-browser options like JupyterLite cannot run compiled solvers — use Colab.)

## License

MIT — see LICENSE.
