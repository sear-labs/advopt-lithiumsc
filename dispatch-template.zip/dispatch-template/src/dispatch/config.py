"""Single source of truth for paths and parameters.

Every other module imports from here. No module ever hardcodes a path
or a magic number, so a scenario change is a config edit, not a code edit.
"""
import os
from pathlib import Path
import yaml


def project_root(start: Path | None = None) -> Path:
    """Locate the repo root (the directory holding config.yaml).

    Tries, in order: an explicit DISPATCH_ROOT env var, the current working
    directory and its parents, then this file's parents. The env var matters
    for non-editable installs, where __file__ lives in site-packages and has
    no config.yaml above it.
    """
    if env := os.environ.get("DISPATCH_ROOT"):
        p = Path(env).resolve()
        if (p / "config.yaml").exists():
            return p
        raise FileNotFoundError(f"DISPATCH_ROOT={env} has no config.yaml")

    candidates = [Path.cwd().resolve()]
    if start is not None:
        candidates.append(Path(start).resolve())
    candidates.append(Path(__file__).resolve())

    for c in candidates:
        for parent in [c, *c.parents]:
            if (parent / "config.yaml").exists():
                return parent
    raise FileNotFoundError(
        "config.yaml not found. Run from the repo root, or set DISPATCH_ROOT."
    )


class Config:
    def __init__(self, config_path: Path | str | None = None):
        self.root = project_root()
        path = Path(config_path) if config_path else self.root / "config.yaml"
        with open(path) as f:
            self._raw = yaml.safe_load(f)

        p = self._raw["paths"]
        self.raw_dir = self.root / p["raw"]
        self.interim_dir = self.root / p["interim"]
        self.processed_dir = self.root / p["processed"]
        self.figures_dir = self.root / p["figures"]
        self.tables_dir = self.root / p["tables"]

        self.run_name = self._raw["run_name"]
        self.model = self._raw["model"]
        self.data = self._raw["data"]
        self.seed = self._raw["random_seed"]

        for d in (self.interim_dir, self.processed_dir,
                  self.figures_dir, self.tables_dir):
            d.mkdir(parents=True, exist_ok=True)

    def __repr__(self):
        # the root's NAME, not its full path: these notebooks ship executed,
        # and an absolute path would bake one machine's home directory into a
        # template other people copy. Use `cfg.root` when you need the full path.
        return f"<Config run_name={self.run_name!r} root=.../{self.root.name}>"
