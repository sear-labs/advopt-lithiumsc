"""Stage 3: processed CSVs -> figures and summary tables.

Reads only from data/processed. Never re-runs the model, so a figure
tweak is a two-second loop instead of a full re-solve.
"""
import matplotlib
matplotlib.use("Agg")  # headless-safe; works in CI and Colab alike
import matplotlib.pyplot as plt
import pandas as pd

from .config import Config


def plot_dispatch_stack(cfg: Config, dispatch: pd.DataFrame,
                        demand: pd.DataFrame):
    pivot = dispatch.pivot_table(index="hour", columns="generator",
                                 values="power_mw", aggfunc="sum").fillna(0)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.stackplot(pivot.index, pivot.T.values, labels=pivot.columns, alpha=0.85)
    ax.plot(demand["hour"], demand["demand_mw"], "k--", lw=2, label="Demand")
    ax.set_xlabel("Hour")
    ax.set_ylabel("Power (MW)")
    ax.set_title(f"Dispatch by unit — run: {cfg.run_name}")
    ax.legend(loc="upper left", fontsize=8, ncol=2)
    ax.margins(x=0)
    fig.tight_layout()
    out = cfg.figures_dir / f"dispatch_stack_{cfg.run_name}.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"  wrote {out.relative_to(cfg.root)}")
    return out


def plot_cost_breakdown(cfg: Config, dispatch: pd.DataFrame):
    by_gen = dispatch.groupby("generator")[
        ["fuel_cost", "startup_cost_incurred"]].sum().sort_values("fuel_cost")
    fig, ax = plt.subplots(figsize=(8, 4.5))
    by_gen.plot(kind="barh", stacked=True, ax=ax)
    ax.set_xlabel("Cost ($)")
    ax.set_ylabel("")
    ax.set_title(f"Cost by unit — run: {cfg.run_name}")
    fig.tight_layout()
    out = cfg.figures_dir / f"cost_breakdown_{cfg.run_name}.png"
    fig.savefig(out, dpi=150)
    plt.close(fig)
    print(f"  wrote {out.relative_to(cfg.root)}")
    return out


def write_tables(cfg: Config, dispatch: pd.DataFrame):
    by_gen = dispatch.groupby("generator").agg(
        energy_mwh=("power_mw", "sum"),
        hours_online=("committed", "sum"),
        startups=("started", "sum"),
        fuel_cost=("fuel_cost", "sum"),
        startup_cost=("startup_cost_incurred", "sum"),
    ).round(2).reset_index()
    by_gen["total_cost"] = by_gen["fuel_cost"] + by_gen["startup_cost"]
    out = cfg.tables_dir / f"unit_summary_{cfg.run_name}.csv"
    by_gen.to_csv(out, index=False)
    print(f"  wrote {out.relative_to(cfg.root)}")
    return by_gen


def run(cfg: Config | None = None):
    cfg = cfg or Config()
    print("[analyze] building figures and tables")
    dispatch = pd.read_csv(cfg.processed_dir / "dispatch.csv")
    demand = pd.read_csv(cfg.interim_dir / "demand_clean.csv")
    plot_dispatch_stack(cfg, dispatch, demand)
    plot_cost_breakdown(cfg, dispatch)
    return write_tables(cfg, dispatch)
