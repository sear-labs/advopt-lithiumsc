"""Stage 2: interim CSVs -> MILP -> processed result CSVs.

A small unit-commitment problem: pick which units run each hour (binary)
and how hard to run them (continuous), minimizing fuel + startup cost
subject to meeting demand plus a reserve margin.

Deliberately solver-agnostic via PuLP so it runs anywhere, including
Colab, with no license.
"""
import pandas as pd
import pulp

from .config import Config


def build_problem(gens: pd.DataFrame, demand: pd.DataFrame, params: dict):
    G = gens["generator"].tolist()
    T = demand["hour"].tolist()
    cap = dict(zip(gens["generator"], gens["capacity_mw"]))
    pmin = dict(zip(gens["generator"], gens["min_output_mw"]))
    mc = dict(zip(gens["generator"], gens["marginal_cost"]))
    sc = dict(zip(gens["generator"], gens["startup_cost"]))
    load = dict(zip(demand["hour"], demand["demand_mw"]))
    reserve = params["reserve_margin"]
    voll = params["unserved_energy_cost"]

    prob = pulp.LpProblem("unit_commitment", pulp.LpMinimize)

    commit = pulp.LpVariable.dicts("commit", (G, T), cat="Binary")
    start = pulp.LpVariable.dicts("start", (G, T), lowBound=0, upBound=1)
    power = pulp.LpVariable.dicts("power", (G, T), lowBound=0)
    unserved = pulp.LpVariable.dicts("unserved", T, lowBound=0)

    prob += (
        pulp.lpSum(mc[g] * power[g][t] for g in G for t in T)
        + pulp.lpSum(sc[g] * start[g][t] for g in G for t in T)
        + pulp.lpSum(voll * unserved[t] for t in T)
    ), "total_cost"

    for t in T:
        prob += (pulp.lpSum(power[g][t] for g in G) + unserved[t]
                 >= load[t]), f"energy_balance_{t}"
        prob += (pulp.lpSum(cap[g] * commit[g][t] for g in G) + unserved[t]
                 >= load[t] * (1 + reserve)), f"reserve_{t}"

    for g in G:
        for i, t in enumerate(T):
            prob += power[g][t] <= cap[g] * commit[g][t], f"pmax_{g}_{t}"
            prob += power[g][t] >= pmin[g] * commit[g][t], f"pmin_{g}_{t}"
            prev = commit[g][T[i - 1]] if i > 0 else 0
            prob += start[g][t] >= commit[g][t] - prev, f"startup_{g}_{t}"

    return prob, {"commit": commit, "power": power,
                  "start": start, "unserved": unserved, "G": G, "T": T}


def solve(cfg: Config, gens: pd.DataFrame, demand: pd.DataFrame):
    prob, v = build_problem(gens, demand, cfg.model)
    solver = pulp.PULP_CBC_CMD(msg=False,
                               timeLimit=cfg.model.get("time_limit_seconds"))
    prob.solve(solver)
    status = pulp.LpStatus[prob.status]
    print(f"  solver status: {status}")
    if status != "Optimal":
        raise RuntimeError(f"model did not solve to optimality: {status}")

    rows = []
    for t in v["T"]:
        for g in v["G"]:
            rows.append({
                "hour": t, "generator": g,
                "power_mw": round(v["power"][g][t].value() or 0.0, 4),
                "committed": int(round(v["commit"][g][t].value() or 0)),
                "started": int(round(v["start"][g][t].value() or 0)),
            })
    dispatch = pd.DataFrame(rows)
    unserved = pd.DataFrame({
        "hour": v["T"],
        "unserved_mw": [round(v["unserved"][t].value() or 0.0, 4)
                        for t in v["T"]],
    })
    return dispatch, unserved, pulp.value(prob.objective)


def run(cfg: Config | None = None):
    cfg = cfg or Config()
    print("[model] building and solving MILP")
    gens = pd.read_csv(cfg.interim_dir / "generators_clean.csv")
    demand = pd.read_csv(cfg.interim_dir / "demand_clean.csv")

    dispatch, unserved, total_cost = solve(cfg, gens, demand)

    merged = dispatch.merge(
        gens[["generator", "marginal_cost", "startup_cost"]], on="generator")
    merged["fuel_cost"] = merged["power_mw"] * merged["marginal_cost"]
    merged["startup_cost_incurred"] = merged["started"] * merged["startup_cost"]

    dispatch_path = cfg.processed_dir / "dispatch.csv"
    merged.to_csv(dispatch_path, index=False)
    unserved.to_csv(cfg.processed_dir / "unserved.csv", index=False)

    summary = pd.DataFrame([{
        "run_name": cfg.run_name,
        "total_cost": round(total_cost, 2),
        "total_energy_mwh": round(merged["power_mw"].sum(), 2),
        "total_startups": int(merged["started"].sum()),
        "unserved_mwh": round(unserved["unserved_mw"].sum(), 4),
        "reserve_margin": cfg.model["reserve_margin"],
    }])
    summary.to_csv(cfg.processed_dir / "summary.csv", index=False)
    print(f"  total cost ${total_cost:,.2f} -> "
          f"{dispatch_path.relative_to(cfg.root)}")
    return merged, unserved, summary
