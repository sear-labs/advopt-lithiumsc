"""Toy unit-commitment pipeline: raw CSV -> clean -> MILP -> analysis."""
__version__ = "0.1.0"
