"""Stage 1: raw CSVs -> validated interim CSVs.

Raw data is treated as read-only and immutable. Everything this stage
produces can be deleted and regenerated, which is why data/interim is
gitignored.
"""
import pandas as pd

from .config import Config

GENERATOR_SCHEMA = {
    "generator": "string", "capacity_mw": "float64",
    "min_output_mw": "float64", "marginal_cost": "float64",
    "startup_cost": "float64",
}
DEMAND_SCHEMA = {"hour": "int64", "demand_mw": "float64"}


def _validate(df: pd.DataFrame, schema: dict, name: str) -> pd.DataFrame:
    missing = set(schema) - set(df.columns)
    if missing:
        raise ValueError(f"{name}: missing required columns {sorted(missing)}")
    df = df[list(schema)].astype(schema)
    if df.isna().any().any():
        bad = df[df.isna().any(axis=1)]
        raise ValueError(f"{name}: {len(bad)} rows with missing values:\n{bad}")
    return df


def clean_generators(cfg: Config) -> pd.DataFrame:
    df = pd.read_csv(cfg.raw_dir / cfg.data["generators"])
    df = _validate(df, GENERATOR_SCHEMA, "generators")

    if (df["min_output_mw"] > df["capacity_mw"]).any():
        raise ValueError("generators: min_output_mw exceeds capacity_mw")
    if (df["marginal_cost"] < 0).any():
        raise ValueError("generators: negative marginal_cost")
    if df["generator"].duplicated().any():
        raise ValueError("generators: duplicate generator names")

    out = cfg.interim_dir / "generators_clean.csv"
    df.to_csv(out, index=False)
    print(f"  cleaned {len(df)} generators -> {out.relative_to(cfg.root)}")
    return df


def clean_demand(cfg: Config) -> pd.DataFrame:
    df = pd.read_csv(cfg.raw_dir / cfg.data["demand"])
    df = _validate(df, DEMAND_SCHEMA, "demand")

    if (df["demand_mw"] < 0).any():
        raise ValueError("demand: negative demand_mw")
    df = df.sort_values("hour").reset_index(drop=True)
    expected = list(range(df["hour"].min(), df["hour"].max() + 1))
    if df["hour"].tolist() != expected:
        raise ValueError("demand: hours are not a complete consecutive range")

    out = cfg.interim_dir / "demand_clean.csv"
    df.to_csv(out, index=False)
    print(f"  cleaned {len(df)} demand periods -> {out.relative_to(cfg.root)}")
    return df


def run(cfg: Config | None = None):
    cfg = cfg or Config()
    print("[clean] validating raw inputs")
    return clean_generators(cfg), clean_demand(cfg)
