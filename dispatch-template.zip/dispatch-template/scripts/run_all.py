#!/usr/bin/env python
"""One command reproduces every result in this repo.

    python scripts/run_all.py
    python scripts/run_all.py --config scenarios/high_reserve.yaml
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from dispatch import analyze, clean, model          # noqa: E402
from dispatch.config import Config                  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default=None, help="path to a config YAML")
    args = ap.parse_args()

    cfg = Config(args.config)
    print(f"=== pipeline start: {cfg!r} ===")
    t0 = time.time()

    clean.run(cfg)
    model.run(cfg)
    analyze.run(cfg)

    print(f"=== done in {time.time() - t0:.1f}s ===")


if __name__ == "__main__":
    main()
