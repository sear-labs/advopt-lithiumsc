"""Smoke test: the whole pipeline runs and the physics makes sense.

Not testing for research correctness — testing that nothing is broken.
This is what CI runs on every push, and it is the single highest-value
test for research code.
"""
import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from dispatch import analyze, clean, model
from dispatch.config import Config


@pytest.fixture(scope="module")
def cfg():
    return Config()


def test_pipeline_runs_end_to_end(cfg):
    clean.run(cfg)
    dispatch, unserved, summary = model.run(cfg)
    analyze.run(cfg)

    assert not dispatch.empty
    assert (cfg.processed_dir / "summary.csv").exists()
    assert len(list(cfg.figures_dir.glob("*.png"))) >= 2


def test_demand_is_met(cfg):
    dispatch = pd.read_csv(cfg.processed_dir / "dispatch.csv")
    demand = pd.read_csv(cfg.interim_dir / "demand_clean.csv")
    supplied = dispatch.groupby("hour")["power_mw"].sum()
    for _, row in demand.iterrows():
        assert supplied[row["hour"]] >= row["demand_mw"] - 1e-6


def test_no_unit_exceeds_capacity(cfg):
    dispatch = pd.read_csv(cfg.processed_dir / "dispatch.csv")
    gens = pd.read_csv(cfg.interim_dir / "generators_clean.csv")
    merged = dispatch.merge(gens[["generator", "capacity_mw"]], on="generator")
    assert (merged["power_mw"] <= merged["capacity_mw"] + 1e-6).all()


def test_rejects_bad_input(cfg, tmp_path):
    bad = pd.DataFrame({"generator": ["g1"], "capacity_mw": [10.0]})
    bad.to_csv(tmp_path / "generators.csv", index=False)
    cfg2 = Config()
    cfg2.raw_dir = tmp_path
    with pytest.raises(ValueError, match="missing required columns"):
        clean.clean_generators(cfg2)
