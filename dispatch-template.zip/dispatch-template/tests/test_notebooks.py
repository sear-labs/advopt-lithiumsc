"""Execute every notebook end-to-end.

This is what makes a teaching notebook safe to write. Notebooks that
duplicate logic for pedagogy are fine PROVIDED something proves they
still agree with src/ — the anti-drift assertion inside
01_model_explained.ipynb does that, and this test runs it.
"""
from pathlib import Path

import nbformat
import pytest
from nbclient import NotebookClient

ROOT = Path(__file__).resolve().parents[1]
NOTEBOOKS = sorted((ROOT / "notebooks").glob("*.ipynb"))


@pytest.mark.parametrize("path", NOTEBOOKS, ids=lambda p: p.name)
def test_notebook_executes(path):
    nb = nbformat.read(path, as_version=4)
    client = NotebookClient(nb, timeout=900, kernel_name="python3",
                            resources={"metadata": {"path": str(path.parent)}})
    client.execute()   # any raised exception, including our assert, fails here
